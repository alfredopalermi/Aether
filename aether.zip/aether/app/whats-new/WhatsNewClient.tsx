'use client'
import Link from 'next/link'
import { useVotes } from '@/hooks/useVotes'
import { useToast } from '@/components/ui/Toast'
import { CATEGORIES } from '@/lib/utils'
import type { Tool } from '@/lib/types'

interface Props { tools: Tool[] }

export function WhatsNewClient({ tools }: Props) {
  const initialVotes = Object.fromEntries(tools.map(t => [t.slug, t.votes ?? 0]))
  const { getVotes, hasVoted, toggle: toggleVote } = useVotes(initialVotes)
  const { toast } = useToast()

  const sorted = [...tools].sort((a, b) => new Date(b.added_at).getTime() - new Date(a.added_at).getTime())

  // Group by month
  const months: Record<string, Tool[]> = {}
  sorted.forEach(t => {
    const key = new Date(t.added_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
    if (!months[key]) months[key] = []
    months[key].push(t)
  })

  const catCounts = Object.fromEntries(
    CATEGORIES.map(c => [c.name, tools.filter(t => t.category === c.name).length])
  )

  const handleVote = async (slug: string) => {
    await toggleVote(slug)
    toast(hasVoted(slug) ? 'Vote removed' : '♥ Voted!')
  }

  return (
    <main className="max-w-[1160px] mx-auto px-6 py-8 pb-24">
      <div className="mb-8 pb-6 border-b border-[var(--border-soft)]">
        <div className="text-sm text-[var(--text-3)] mb-2">Home / What&apos;s New</div>
        <h1 className="page-title mb-1.5">What&apos;s New</h1>
        <p className="text-sm text-[var(--text-2)] font-light">Every tool we&apos;ve added, with our honest take on each.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_230px] gap-10 items-start">
        {/* Feed */}
        <div>
          {Object.entries(months).map(([month, monthTools]) => (
            <div key={month} className="mb-12">
              <div className="flex items-center gap-3 font-serif text-xl tracking-tight mb-5 pb-3 border-b border-[var(--border)]">
                {month}
                <span className="text-sm text-[var(--text-3)] font-sans font-normal">
                  {monthTools.length} added
                </span>
              </div>

              {monthTools.map(t => {
                const d = new Date(t.added_at)
                const voted = hasVoted(t.slug)
                return (
                  <div key={t.slug} className="flex gap-5 py-4 border-b border-[var(--border-soft)] last:border-0 cursor-pointer group"
                       onClick={() => window.location.href = `/tool/${t.slug}`}>
                    {/* Date */}
                    <div className="min-w-[52px] pt-0.5">
                      <div className="font-serif text-[20px] leading-none tracking-tight">{d.getDate()}</div>
                      <div className="text-[10px] text-[var(--text-3)] uppercase tracking-widest">
                        {d.toLocaleDateString('en-US', { month: 'short' })}
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-base">{t.logo}</span>
                        <span className="text-sm font-semibold group-hover:text-[var(--text)] transition-colors">
                          {t.name}
                        </span>
                      </div>
                      <p className="text-sm text-[var(--text-2)] leading-relaxed mb-2.5 italic">
                        {t.editorial ?? t.tagline}
                      </p>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`badge badge-${t.pricing.toLowerCase()}`}>{t.pricing}</span>
                        <span className="badge">{t.category}</span>
                        <button
                          onClick={e => { e.stopPropagation(); handleVote(t.slug) }}
                          className={`flex items-center gap-1 px-2 py-0.5 rounded-md border text-xs transition-all font-medium
                            ${voted
                              ? 'bg-red-50 border-red-200 text-red-600 dark:bg-red-900/20 dark:border-red-800 dark:text-red-400'
                              : 'border-[var(--border)] bg-[var(--surface)] text-[var(--text-3)] hover:border-red-300 hover:text-red-500'}`}>
                          ♥ {getVotes(t.slug)}
                        </button>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          ))}
        </div>

        {/* Sidebar */}
        <aside className="hidden lg:block sticky top-20 space-y-3">
          {/* By Category */}
          <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-4">
            <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-3)] mb-3">By Category</div>
            {CATEGORIES.map(c => (
              <Link key={c.name} href={`/directory?category=${c.name}`}
                    className="flex items-center justify-between py-1.5 text-sm text-[var(--text-2)] hover:text-[var(--text)] transition-colors">
                <span>{c.icon} {c.name}</span>
                <span className="text-[11px] text-[var(--text-3)]">{catCounts[c.name]}</span>
              </Link>
            ))}
          </div>

          {/* Newsletter */}
          <div className="bg-[var(--text)] text-[var(--text-inv)] rounded-xl p-4">
            <div className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-2">Newsletter</div>
            <p className="text-sm opacity-55 mb-3 font-light leading-relaxed">New tools every week in your inbox.</p>
            <input type="email" placeholder="your@email.com"
                   className="w-full px-3 py-2 rounded-lg border border-white/15 bg-white/10 text-white placeholder:text-white/35 text-sm outline-none focus:border-white/35 mb-2" />
            <button className="w-full py-2 rounded-lg bg-white text-[#111] text-sm font-medium hover:opacity-90 transition-opacity">
              Subscribe
            </button>
          </div>
        </aside>
      </div>
    </main>
  )
}
