'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ToolCard } from '@/components/tools/ToolCard'
import { ToastProvider } from '@/components/ui/Toast'
import { useVotes } from '@/hooks/useVotes'
import { useBookmarks } from '@/hooks/useBookmarks'
import { useVisited } from '@/hooks/useVisited'
import { CATEGORIES, getTOTWSlug, getWeekNumber } from '@/lib/utils'
import type { Tool, Category } from '@/lib/types'

interface Props { tools: Tool[] }

export function HomeClient({ tools }: Props) {
  const router = useRouter()
  const initialVotes = Object.fromEntries(tools.map(t => [t.slug, t.votes ?? 0]))
  const { getVotes, hasVoted, toggle: toggleVote, total: totalVotes } = useVotes(initialVotes)
  const { bookmarks } = useBookmarks()
  const { visited } = useVisited()

  const [heroFilter, setHeroFilter] = useState<Category | 'All'>('All')
  const [searchQ, setSearchQ] = useState('')
  const [counts, setCounts] = useState({ tools: 0, cats: 0, votes: 0 })

  // Animated counters
  useEffect(() => {
    const target = { tools: tools.length, cats: CATEGORIES.length, votes: totalVotes }
    const duration = 900
    const start = Date.now()
    const step = () => {
      const p = Math.min((Date.now() - start) / duration, 1)
      const e = 1 - Math.pow(1 - p, 3)
      setCounts({
        tools: Math.round(e * target.tools),
        cats: Math.round(e * target.cats),
        votes: Math.round(e * target.votes),
      })
      if (p < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [])

  const filteredTools = tools.filter(t => {
    const matchCat = heroFilter === 'All' || t.category === heroFilter
    const matchQ = !searchQ || t.name.toLowerCase().includes(searchQ.toLowerCase()) ||
                   t.tagline.toLowerCase().includes(searchQ.toLowerCase()) ||
                   t.tags.some(x => x.toLowerCase().includes(searchQ.toLowerCase()))
    return matchCat && matchQ
  })

  const featured = tools.filter(t => t.featured)
  const newest = [...tools].sort((a, b) => new Date(b.added_at).getTime() - new Date(a.added_at).getTime()).slice(0, 6)
  const topVoted = [...tools].sort((a, b) => getVotes(b.slug) - getVotes(a.slug)).slice(0, 6)
  const totwSlug = getTOTWSlug(tools)
  const totw = tools.find(t => t.slug === totwSlug) ?? tools[0]

  // For You
  const forYouTools = (() => {
    const interestSlugs = [...new Set([...bookmarks, ...visited.slice(-10)])]
    if (interestSlugs.length < 2) return []
    const catFreq: Record<string, number> = {}
    const tagFreq: Record<string, number> = {}
    interestSlugs.forEach(slug => {
      const t = tools.find(x => x.slug === slug)
      if (!t) return
      catFreq[t.category] = (catFreq[t.category] ?? 0) + 1
      t.tags.forEach(tag => { tagFreq[tag] = (tagFreq[tag] ?? 0) + 1 })
    })
    return tools
      .filter(t => !bookmarks.includes(t.slug))
      .map(t => ({ t, score: (catFreq[t.category] ?? 0) * 3 + t.tags.reduce((s, tag) => s + (tagFreq[tag] ?? 0), 0) + (getVotes(t.slug) * 0.5) - (visited.includes(t.slug) ? 5 : 0) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 4)
      .map(x => x.t)
  })()

  const topCat = Object.entries(Object.fromEntries(
    [...bookmarks, ...visited].map(slug => tools.find(t => t.slug === slug)?.category).filter(Boolean).map(c => [c!, 1])
  )).sort((a, b) => b[1] - a[1])[0]?.[0]

  const handleVote = async (slug: string) => { await toggleVote(slug) }
  const showFiltered = heroFilter !== 'All' || searchQ

  return (
    <ToastProvider>
      {/* Hero */}
      <section className="py-20 text-center border-b border-[var(--border-soft)] overflow-hidden">
        <div className="max-w-[1160px] mx-auto px-6">
          <div className="inline-flex items-center gap-2.5 text-[11px] uppercase tracking-widest text-[var(--text-3)] font-medium mb-8">
            <span className="w-6 h-px bg-[var(--border)]" />
            AI Tools Directory · Curated Weekly
            <span className="w-6 h-px bg-[var(--border)]" />
          </div>

          <h1 className="font-serif text-[clamp(38px,6.5vw,72px)] leading-[1.07] tracking-[-2px] mb-5 max-w-[680px] mx-auto">
            Discover tools that<br /><em className="italic text-[var(--text-2)]">think with you</em>
          </h1>
          <p className="text-base text-[var(--text-2)] font-light leading-relaxed max-w-[380px] mx-auto mb-9">
            A curated library for writers, designers, marketers, and knowledge workers.
          </p>

          {/* Stats */}
          <div className="flex justify-center gap-10 mb-9">
            {[['tools', 'Tools'], ['cats', 'Categories'], ['votes', 'Votes']].map(([k, label]) => (
              <div key={k} className="flex flex-col items-center gap-0.5">
                <strong className="font-serif text-[26px] tracking-tight leading-none">
                  {counts[k as keyof typeof counts]}
                </strong>
                <span className="text-[11px] text-[var(--text-3)] uppercase tracking-[0.04em]">{label}</span>
              </div>
            ))}
          </div>

          {/* Search */}
          <button onClick={() => router.push('/directory')}
                  className="flex items-center gap-3 px-4 py-3.5 border border-[var(--border)] rounded-xl bg-[var(--surface)] shadow-[var(--shadow)] max-w-[520px] mx-auto w-full text-left cursor-text mb-6 transition-all hover:shadow-[var(--shadow-md)] hover:border-[var(--text-3)]">
            <span className="text-lg text-[var(--text-3)]">⌕</span>
            <span className="text-[15px] text-[var(--text-3)] flex-1">Search {tools.length}+ AI tools…</span>
            <span className="text-xs text-[var(--text-3)]">⌘K</span>
          </button>

          {/* Ticker */}
          <div className="overflow-hidden mb-6" style={{ maskImage: 'linear-gradient(to right,transparent 0%,black 8%,black 92%,transparent 100%)' }}>
            <div className="flex w-max animate-[ticker_32s_linear_infinite] hover:[animation-play-state:paused]">
              {[...tools, ...tools].map((t, i) => (
                <Link key={i} href={`/tool/${t.slug}`}
                      className="px-3.5 py-1.5 rounded-full border border-[var(--border)] bg-[var(--surface)] text-xs text-[var(--text-2)] whitespace-nowrap mx-1 transition-all hover:border-[var(--text-3)] hover:text-[var(--text)]">
                  {t.logo} {t.name}
                </Link>
              ))}
            </div>
          </div>

          {/* Category pills */}
          <div className="flex flex-wrap justify-center gap-1.5 md:flex-nowrap md:overflow-x-auto md:justify-start md:px-0 max-w-2xl mx-auto">
            {['All', ...CATEGORIES.map(c => c.name)].map(cat => (
              <button key={cat} onClick={() => setHeroFilter(cat as Category | 'All')}
                      className={`px-3.5 py-1.5 rounded-full border text-sm transition-all whitespace-nowrap ${heroFilter === cat ? 'bg-[var(--text)] text-[var(--text-inv)] border-[var(--text)]' : 'bg-[var(--surface)] text-[var(--text-2)] border-[var(--border)] hover:border-[var(--text-3)] hover:text-[var(--text)]'}`}>
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-[1160px] mx-auto px-6">
        {/* Filtered results */}
        {showFiltered ? (
          <section className="py-14">
            <div className="flex items-baseline justify-between mb-6 pb-4 border-b border-[var(--border-soft)]">
              <h2 className="font-serif text-2xl tracking-tight">{heroFilter !== 'All' ? heroFilter : `"${searchQ}"`}</h2>
              <button onClick={() => { setHeroFilter('All'); setSearchQ('') }} className="text-sm text-[var(--text-3)] hover:text-[var(--text)] transition-colors">Clear ×</button>
            </div>
            {filteredTools.length === 0
              ? <div className="text-center py-16 text-[var(--text-3)]"><div className="text-3xl mb-3 opacity-40">◯</div><p>No tools found. Try a different filter.</p></div>
              : <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">{filteredTools.map(t => <ToolCard key={t.slug} tool={{ ...t, votes: getVotes(t.slug) }} variant="m" onVote={handleVote} hasVoted={hasVoted(t.slug)} />)}</div>
            }
          </section>
        ) : (
          <>
            {/* Featured */}
            <section className="py-14">
              <SectionHeader title="Featured Tools" linkHref="/directory" linkLabel="All tools →" />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                {featured[0] && <ToolCard tool={{ ...featured[0], votes: getVotes(featured[0].slug) }} variant="l" onVote={handleVote} hasVoted={hasVoted(featured[0].slug)} />}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {featured.slice(1, 5).map(t => <ToolCard key={t.slug} tool={{ ...t, votes: getVotes(t.slug) }} variant="s" onVote={handleVote} hasVoted={hasVoted(t.slug)} />)}
                </div>
              </div>
            </section>

            <div className="h-px bg-[var(--border-soft)]" />

            {/* Tool of the Week */}
            <section className="py-14">
              <SectionHeader title="Tool of the Week" linkHref="/whats-new" linkLabel="What's New →" />
              <Link href={`/tool/${totw.slug}`}
                    className="grid grid-cols-1 lg:grid-cols-2 border border-[var(--border)] rounded-xl overflow-hidden hover:shadow-[var(--shadow-md)] hover:border-gray-300 dark:hover:border-gray-600 transition-all">
                <div className="p-8 flex flex-col gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl border border-[var(--border)] bg-[var(--accent-soft)] flex items-center justify-center text-xl">{totw.logo}</div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="badge badge-featured">✦ Pick</span>
                      <span className={`badge badge-${totw.pricing.toLowerCase()}`}>{totw.pricing}</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-[var(--text-3)] font-bold mb-2">
                      <span className="w-4 h-px bg-[var(--border)]" />
                      Tool of the Week · W{getWeekNumber()}
                    </div>
                    <h3 className="font-serif text-[28px] tracking-tight leading-tight mb-3">{totw.name}</h3>
                    {totw.editorial && <p className="text-sm text-[var(--text-2)] leading-relaxed italic">"{totw.editorial}"</p>}
                  </div>
                  <div className="text-sm text-[var(--text-3)] mt-auto flex items-center gap-1">
                    <span>{totw.category}</span><span>·</span><span>Read more →</span>
                  </div>
                </div>
                <div className="bg-[var(--bg-2)] border-t lg:border-t-0 lg:border-l border-[var(--border)] p-7 flex flex-col justify-center gap-2.5">
                  <div className="text-[10px] uppercase tracking-widest text-[var(--text-3)] font-bold mb-2">At a glance</div>
                  {[
                    ['Category', totw.category],
                    ['Pricing', totw.pricing],
                    ['Votes', String(getVotes(totw.slug))],
                    ['Top use case', totw.use_cases[0]],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-center justify-between py-1.5 border-b border-[var(--border-soft)] last:border-0 text-sm">
                      <span className="text-[var(--text-3)]">{k}</span>
                      <span className="font-medium">{v}</span>
                    </div>
                  ))}
                </div>
              </Link>
            </section>

            <div className="h-px bg-[var(--border-soft)]" />

            {/* For You */}
            {forYouTools.length >= 2 && (
              <>
                <section className="py-14">
                  <div className="flex items-start justify-between mb-6 pb-4 border-b border-[var(--border-soft)]">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h2 className="font-serif text-2xl tracking-tight">For You</h2>
                        <span className="text-[10px] font-bold uppercase tracking-widest bg-blue-50 text-blue-600 border border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800 px-2 py-0.5 rounded-full">Personalized</span>
                      </div>
                      <p className="text-[11px] text-[var(--text-3)]">
                        Based on your interest in {topCat ?? 'saved tools'}
                      </p>
                    </div>
                    <Link href="/bookmarks" className="text-sm text-[var(--text-3)] hover:text-[var(--text)] transition-colors">Saved →</Link>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {forYouTools.map(t => <ToolCard key={t.slug} tool={{ ...t, votes: getVotes(t.slug) }} variant="m" onVote={handleVote} hasVoted={hasVoted(t.slug)} />)}
                  </div>
                </section>
                <div className="h-px bg-[var(--border-soft)]" />
              </>
            )}

            {/* Categories */}
            <section className="py-14">
              <SectionHeader title="Browse by Category" linkHref="/categories" linkLabel="All →" />
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
                {CATEGORIES.map(c => {
                  const count = tools.filter(t => t.category === c.name).length
                  return (
                    <button key={c.name} onClick={() => setHeroFilter(c.name)}
                            className="card-base p-5 text-center flex flex-col items-center gap-2">
                      <span className="text-xl">{c.icon}</span>
                      <span className="text-sm font-medium">{c.name}</span>
                      <span className="text-[11px] text-[var(--text-3)]">{count} tools</span>
                    </button>
                  )
                })}
              </div>
            </section>

            <div className="h-px bg-[var(--border-soft)]" />

            {/* Newest */}
            <section className="py-14">
              <SectionHeader title="Newest Additions" linkHref="/whats-new" linkLabel="What's New →" />
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {newest.map(t => <ToolCard key={t.slug} tool={{ ...t, votes: getVotes(t.slug) }} variant="m" onVote={handleVote} hasVoted={hasVoted(t.slug)} />)}
              </div>
            </section>

            <div className="h-px bg-[var(--border-soft)]" />

            {/* Most Loved */}
            <section className="py-14">
              <SectionHeader title="Most Loved" linkHref="/directory" linkLabel="See all →" />
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {topVoted.map(t => <ToolCard key={t.slug} tool={{ ...t, votes: getVotes(t.slug) }} variant="s" onVote={handleVote} hasVoted={hasVoted(t.slug)} />)}
              </div>
            </section>

            {/* Newsletter */}
            <div className="mb-16 bg-[var(--text)] text-[var(--text-inv)] rounded-xl p-12 text-center">
              <h2 className="font-serif text-3xl tracking-tight mb-2.5">Stay ahead of the curve</h2>
              <p className="text-sm opacity-55 mb-7 font-light">New tools, honest reviews, curated picks — every week.</p>
              <div className="flex gap-2 max-w-[340px] mx-auto">
                <input type="email" placeholder="your@email.com"
                       className="flex-1 px-3.5 py-2.5 rounded-lg border border-white/15 bg-white/10 text-white placeholder:text-white/35 outline-none focus:border-white/35 text-sm" />
                <button className="px-4 py-2.5 rounded-lg bg-white text-[#111] text-sm font-medium hover:opacity-90 transition-opacity whitespace-nowrap">Subscribe</button>
              </div>
            </div>
          </>
        )}
      </div>
    </ToastProvider>
  )
}

function SectionHeader({ title, linkHref, linkLabel }: { title: string; linkHref: string; linkLabel: string }) {
  return (
    <div className="flex items-baseline justify-between mb-6 pb-4 border-b border-[var(--border-soft)]">
      <h2 className="font-serif text-2xl tracking-tight">{title}</h2>
      <Link href={linkHref} className="text-sm text-[var(--text-3)] hover:text-[var(--text)] transition-colors">{linkLabel}</Link>
    </div>
  )
}
