'use client'
import { useState } from 'react'
import { useToast } from '@/components/ui/Toast'
import { CATEGORIES } from '@/lib/utils'

export function SubmitClient() {
  const { toast } = useToast()
  const [form, setForm] = useState({
    name: '', url: '', category: '', pricing: 'Freemium', description: '', email: '',
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.url || !form.category || !form.description) {
      toast('Please fill in all required fields')
      return
    }
    toast('Submission received — thank you! We\'ll review it shortly.')
    setForm({ name: '', url: '', category: '', pricing: 'Freemium', description: '', email: '' })
  }

  return (
    <main className="max-w-[640px] mx-auto px-6 py-8 pb-24">
      <div className="mb-8 pb-6 border-b border-[var(--border-soft)]">
        <div className="text-sm text-[var(--text-3)] mb-2">Home / Submit</div>
        <h1 className="page-title mb-1.5">Submit a Tool</h1>
        <p className="text-sm text-[var(--text-2)] font-light">Know an AI tool that belongs here? Tell us about it and we&apos;ll review it.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <Field label="Tool Name *">
          <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                 placeholder="e.g. Notion, Midjourney…"
                 className="form-input" />
        </Field>

        <Field label="Website URL *">
          <input type="url" value={form.url} onChange={e => setForm(p => ({ ...p, url: e.target.value }))}
                 placeholder="https://…"
                 className="form-input" />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Category *">
            <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                    className="form-input">
              <option value="">Select…</option>
              {CATEGORIES.map(c => <option key={c.name}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Pricing">
            <select value={form.pricing} onChange={e => setForm(p => ({ ...p, pricing: e.target.value }))}
                    className="form-input">
              <option>Free</option>
              <option>Freemium</option>
              <option>Paid</option>
            </select>
          </Field>
        </div>

        <Field label="Short Description *">
          <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                    placeholder="2–3 sentences on what this tool does and who it's for."
                    rows={4} className="form-input resize-y" />
        </Field>

        <Field label="Your email (optional)">
          <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                 placeholder="We'll notify you if it's added"
                 className="form-input" />
        </Field>

        <button type="submit" className="btn-solid px-7 py-2.5 text-sm">Submit for Review</button>
      </form>

      <style jsx>{`
        .form-input {
          width: 100%;
          padding: 10px 12px;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          font-family: var(--font-dm-sans), system-ui, sans-serif;
          font-size: 14px;
          color: var(--text);
          background: var(--surface);
          outline: none;
          transition: border-color 160ms ease;
        }
        .form-input:focus { border-color: var(--text-3); }
      `}</style>
    </main>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-[11px] font-bold uppercase tracking-widest text-[var(--text-2)] mb-1.5">{label}</label>
      {children}
    </div>
  )
}
