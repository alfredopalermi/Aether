import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { SubmitClient } from './SubmitClient'
import { ToastProvider } from '@/components/ui/Toast'
import { TOOLS } from '@/data/tools'

export const metadata = { title: 'Submit a Tool — Aether', description: 'Suggest a tool for the Aether directory.' }

export default function SubmitPage() {
  return (
    <ToastProvider>
      <Navbar tools={TOOLS} />
      <SubmitClient />
      <Footer />
    </ToastProvider>
  )
}
