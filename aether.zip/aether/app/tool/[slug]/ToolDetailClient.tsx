'use client'
import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { ToolCard } from '@/components/tools/ToolCard'
import { useBookmarks } from '@/hooks/useBookmarks'
import { useCompare } from '@/hooks/useCompare'
import { useVisited } from '@/hooks/useVisited'
import { useNotes } from '@/hooks/useNotes'
import { useVotes } from '@/hooks/useVotes'
import { useToast } from '@/components/ui/Toast'
import { getCategoryMeta } from '@/lib/utils'
import type { Tool } from '@/lib/types'

interface Props { tool: Tool; allTools: Tool[] }

export function ToolDetailClient({ tool: t, allTools }: Props) {
  const { isBookmarked, toggle: toggleBm } = useBookmarks()
  const { isInCompare, toggle: toggleCmp } = useCompare()
  const { markVisited } = useVisited()
  const { getNote, saveNote } = useNotes()
  const initialVotes = Object.fromEntries(allTools.map(x => [x.slug, x.votes ?? 0]))
  const { getVotes, hasVoted, toggle: toggleVote } = useVotes(initialVotes)
  const { toast } = useToast()

  const [note, setNote] = useState('')
  const [noteSaved, setNoteSaved] = useState(false)
  const saveTimer = useRef<ReturnType<typeof setTimeout>>()
  const catMeta = getCategoryMeta(t.category)

  useEffect(() => {
    markVisited(t.slug)
    setNote(getNote(t.slug))
  }, [t.slug])

  const handleNoteChange = (val: string) => {
    setNote(val)
    clearTimeout(saveTimer.current)
    saveTimer.current = setTimeout(() => {
      saveNote(t.slug, val)
      setNoteSaved(true)
      setTimeout(() => setNoteSaved(false), 1800)
    }, 600)
  }

  // Prev / Next in same category
  const catTools = allTools.filter(x => x.category === t.category)
  const idx = catTools.findIndex(x => x.slug === t.slug)
  const prev = idx > 0 ? catTools[idx - 1] : null
  const next = idx < catTools.length - 1 ? catTools[idx + 1] : null

  // Related tools (same category, excluding current)
  const related = allTools.filter(x => x.category === t.category && x.slug !== t.slug).slice(0, 3)

  const bm = isBookmarked(t.slug)
  const cmp = isInCompare(t.slug)

  return (
    <main className="max-w-[1160px] mx-auto px-6 py-8 pb-24">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5 text-sm text-[var(--text-3)] mb-5 flex-wrap">
        <Link href="/" className="hover:text-[var(--text)] transition-colors">Home</Link>
        <span className="text-[var(--border)]">/</span>
        <Link href="/directory" className="hover:text-[var(--text)] transition-colors">Directory</Link>
        <span className="text-[var(--border)]">/</span>
        <span>{t.name}</span>
      </div>

      {/* Header */}
      <div className="pb-8 border-b border-[var(--border)] mb-10">
        <div className="flex items-start gap-5">
          <div className="w-[58px] h-[58px] rounded-[14px] border border-[var(--border)] bg-[var(--accent-soft)] flex items-center justify-center text-2xl shrink-0">{t.logo}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              {t.featured && <span className="badge badge-featured">✦ Editor's Pick</span>}
              <span className={`badge badge-${t.pricing.toLowerCase()}`}>{t.pricing}</span>
            </div>
            <h1 className="font-serif text-[36px] tracking-tight leading-tight mb-2">{t.name}</h1>
            <p className="text-[15px] text-[var(--text-2)] font-light leading-relaxed mb-4">{t.tagline}</p>
            <div className="flex items-center gap-2 flex-wrap">
              <a href={t.website} target="_blank" rel="noopener noreferrer" className="btn-solid">Visit Website →</a>
              <button onClick={() => { toggleBm(t.slug); toast(bm ? 'Removed from saved' : 'Saved ♥') }}
                      className="btn-ghost">{bm ? '♥ Saved' : '♡ Save'}</button>
              <button onClick={() => { const r = toggleCmp(t.slug); if (r === 'max') toast('Max 3 tools'); else toast(r === 'added' ? 'Added to compare ⊕' : 'Removed') }}
                      className="btn-ghost">{cmp ? '⊕ In Compare' : '⊕ Compare'}</button>
              <button onClick={async () => { await toggleVote(t.slug); toast(hasVoted(t.slug) ? 'Vote removed' : '♥ Voted!') }}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm font-medium transition-all ${hasVoted(t.slug) ? 'bg-red-50 border-red-200 text-red-600 dark:bg-red-900/20 dark:border-red-800 dark:text-red-400' : 'btn-ghost'}`}>
                ♥ {getVotes(t.slug)}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_260px] gap-10 items-start">
        {/* Main content */}
        <div>
          <Section title="About">
            <p className="text-[15px] text-[var(--text-2)] leading-[1.75]">{t.description}</p>
          </Section>

          <Section title="Strengths & Limitations">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 dark:bg-emerald-900/10 dark:border-emerald-800">
                <div className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mb-2">Strengths</div>
                <ul className="space-y-1">{t.pros.map(p => <li key={p} className="text-sm text-[var(--text-2)] pl-4 relative before:content-['✓'] before:absolute before:left-0 before:text-emerald-500 before:font-bold">{p}</li>)}</ul>
              </div>
              <div className="p-3.5 rounded-lg bg-rose-50 border border-rose-200 dark:bg-rose-900/10 dark:border-rose-800">
                <div className="text-[10px] font-bold text-rose-600 uppercase tracking-widest mb-2">Limitations</div>
                <ul className="space-y-1">{t.cons.map(c => <li key={c} className="text-sm text-[var(--text-2)] pl-4 relative before:content-['×'] before:absolute before:left-0 before:text-rose-500 before:font-bold">{c}</li>)}</ul>
              </div>
            </div>
          </Section>

          <Section title="Use Cases">
            <div className="flex flex-wrap gap-1.5">
              {t.use_cases.map(u => (
                <Link key={u} href={`/directory?tag=${encodeURIComponent(u)}`} className="tag">{u}</Link>
              ))}
            </div>
          </Section>

          {related.length > 0 && (
            <Section title="Related Tools">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {related.map(r => <ToolCard key={r.slug} tool={r} variant="s" hasVoted={hasVoted(r.slug)} />)}
              </div>
            </Section>
          )}
        </div>

        {/* Sidebar */}
        <aside className="space-y-3">
          {/* Info card */}
          <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-4">
            <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-3)] mb-3">Tool Info</div>
            {[
              ['Category', t.category],
              ['Pricing', t.pricing],
              ['Added', new Date(t.added_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })],
              ['Votes', String(getVotes(t.slug))],
            ].map(([k, v]) => (
              <div key={k} className="flex items-center justify-between py-1.5 border-b border-[var(--border-soft)] last:border-0 text-sm">
                <span className="text-[var(--text-3)]">{k}</span>
                <span>{v}</span>
              </div>
            ))}
          </div>

          {/* Tags */}
          <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-4">
            <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-3)] mb-3">Tags</div>
            <div className="flex flex-wrap gap-1.5">
              {t.tags.map(tag => (
                <Link key={tag} href={`/directory?tag=${encodeURIComponent(tag)}`} className="tag">{tag}</Link>
              ))}
            </div>
          </div>

          {/* Browse category */}
          <div className="bg-[var(--bg)] border border-[var(--border)] rounded-xl p-4">
            <div className="text-sm font-medium mb-1.5">Not the right fit?</div>
            <p className="text-xs text-[var(--text-2)] mb-3">Browse other tools in the same category.</p>
            <Link href={`/directory?category=${t.category}`}
                  className="btn-ghost w-full justify-center text-sm">Browse {t.category} →</Link>
          </div>

          {/* Personal notes */}
          <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-4">
            <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-[var(--text-3)] mb-3">
              My Notes
              <span className="font-normal normal-case tracking-normal text-[11px]">{note.length}/280</span>
            </div>
            <textarea value={note} onChange={e => handleNoteChange(e.target.value)} maxLength={280}
                      placeholder="Add a personal note… 'Evaluate for project X', 'Too expensive but watch'"
                      className="w-full min-h-[78px] resize-y p-2.5 rounded-lg border border-[var(--border)] bg-[var(--bg)] text-sm text-[var(--text)] outline-none focus:border-[var(--text-3)] leading-relaxed placeholder:text-[var(--text-3)] transition-colors" />
            <div className="flex items-center justify-between mt-2">
              <span className={`text-[11px] text-emerald-500 transition-opacity ${noteSaved ? 'opacity-100' : 'opacity-0'}`}>✓ Saved</span>
              <button onClick={() => { handleNoteChange(''); saveNote(t.slug, '') }} className="btn-ghost text-xs py-1 px-2.5">Clear</button>
            </div>
          </div>
        </aside>
      </div>

      {/* Prev / Next */}
      <div className="flex justify-between items-stretch pt-5 border-t border-[var(--border-soft)] mt-2 gap-2.5">
        {prev ? (
          <Link href={`/tool/${prev.slug}`}
                className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] hover:border-[var(--text-3)] hover:shadow-sm transition-all max-w-[48%] flex-1">
            <span className="text-[var(--text-3)]">←</span>
            <div className="w-7 h-7 rounded-md border border-[var(--border)] bg-[var(--accent-soft)] flex items-center justify-center text-sm shrink-0">{prev.logo}</div>
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-widest text-[var(--text-3)] font-bold">Previous in {t.category}</div>
              <div className="text-sm font-medium truncate">{prev.name}</div>
            </div>
          </Link>
        ) : <div />}
        {next ? (
          <Link href={`/tool/${next.slug}`}
                className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] hover:border-[var(--text-3)] hover:shadow-sm transition-all max-w-[48%] flex-1 flex-row-reverse text-right ml-auto">
            <span className="text-[var(--text-3)]">→</span>
            <div className="w-7 h-7 rounded-md border border-[var(--border)] bg-[var(--accent-soft)] flex items-center justify-center text-sm shrink-0">{next.logo}</div>
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-widest text-[var(--text-3)] font-bold">Next in {t.category}</div>
              <div className="text-sm font-medium truncate">{next.name}</div>
            </div>
          </Link>
        ) : <div />}
      </div>
    </main>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-7">
      <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-3)] mb-2.5 pb-2 border-b border-[var(--border-soft)]">{title}</div>
      {children}
    </div>
  )
}
