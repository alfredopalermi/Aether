import { notFound } from 'next/navigation'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { CompareBar } from '@/components/compare/CompareBar'
import { ToolDetailClient } from './ToolDetailClient'
import { ToastProvider } from '@/components/ui/Toast'
import { TOOLS } from '@/data/tools'
import { createServerClient } from '@/lib/supabase'

export const revalidate = 60

export async function generateStaticParams() {
  return TOOLS.map(t => ({ slug: t.slug }))
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const tool = TOOLS.find(t => t.slug === params.slug)
  if (!tool) return {}
  return {
    title: `${tool.name} — Aether`,
    description: tool.tagline,
  }
}

async function getVotes(): Promise<Record<string, number>> {
  try {
    const supabase = createServerClient()
    const { data } = await supabase.from('votes').select('tool_slug, count')
    const map: Record<string, number> = {}
    data?.forEach(v => { map[v.tool_slug] = v.count })
    return map
  } catch { return {} }
}

export default async function ToolPage({ params }: { params: { slug: string } }) {
  const tool = TOOLS.find(t => t.slug === params.slug)
  if (!tool) notFound()

  const votesMap = await getVotes()
  const tools = TOOLS.map(t => ({ ...t, votes: votesMap[t.slug] ?? 0 }))
  const toolWithVotes = { ...tool, votes: votesMap[tool.slug] ?? 0 }

  return (
    <ToastProvider>
      <Navbar tools={tools} />
      <ToolDetailClient tool={toolWithVotes} allTools={tools} />
      <Footer />
      <CompareBar tools={tools} />
    </ToastProvider>
  )
}
