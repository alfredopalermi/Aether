'use client'
import { useState, useMemo } from 'react'
import { ToolCard } from '@/components/tools/ToolCard'
import { ToolListItem } from '@/components/tools/ToolListItem'
import { useVotes } from '@/hooks/useVotes'
import { CATEGORIES, filterTools } from '@/lib/utils'
import type { Tool, Category, Pricing, SortOption, ViewMode } from '@/lib/types'

interface Props { tools: Tool[] }

export function DirectoryClient({ tools }: Props) {
  const initialVotes = Object.fromEntries(tools.map(t => [t.slug, t.votes ?? 0]))
  const { getVotes, hasVoted, toggle: toggleVote } = useVotes(initialVotes)

  const [category, setCategory] = useState<Category | 'All'>('All')
  const [pricing, setPricing] = useState<Pricing | 'All'>('All')
  const [sort, setSort] = useState<SortOption>('newest')
  const [tag, setTag] = useState<string | null>(null)
  const [view, setView] = useState<ViewMode>('grid')

  const filtered = useMemo(() =>
    filterTools(tools.map(t => ({ ...t, votes: getVotes(t.slug) })), { category, pricing, sort, tag: tag ?? undefined }),
    [tools, category, pricing, sort, tag]
  )

  const priceCounts = { Free: tools.filter(t => t.pricing === 'Free').length, Freemium: tools.filter(t => t.pricing === 'Freemium').length, Paid: tools.filter(t => t.pricing === 'Paid').length }
  const catCounts = Object.fromEntries(CATEGORIES.map(c => [c.name, tools.filter(t => t.category === c.name).length]))

  const handleVote = async (slug: string) => { await toggleVote(slug) }

  return (
    <main className="max-w-[1160px] mx-auto px-6 py-8 pb-24">
      {/* Header */}
      <div className="mb-8 pb-6 border-b border-[var(--border-soft)]">
        <div className="text-sm text-[var(--text-3)] mb-2">Home / Directory</div>
        <h1 className="page-title mb-1.5">All Tools</h1>
        <p className="text-sm text-[var(--text-2)] font-light">The complete AI tools library — filtered to your needs.</p>
      </div>

      {/* Filter bar */}
      <div className="flex items-center gap-3 bg-[var(--surface)] border border-[var(--border)] rounded-xl px-4 py-3 mb-3 flex-wrap overflow-x-auto">
        <FilterGroup label="Category">
          <select value={category} onChange={e => setCategory(e.target.value as Category | 'All')}
                  className="text-sm bg-[var(--bg-2)] border border-[var(--border)] rounded-md px-2 py-1 text-[var(--text)] outline-none">
            <option value="All">All</option>
            {CATEGORIES.map(c => <option key={c.name}>{c.name}</option>)}
          </select>
        </FilterGroup>
        <div className="w-px h-4 bg-[var(--border)] shrink-0" />
        <FilterGroup label="Pricing">
          <select value={pricing} onChange={e => setPricing(e.target.value as Pricing | 'All')}
                  className="text-sm bg-[var(--bg-2)] border border-[var(--border)] rounded-md px-2 py-1 text-[var(--text)] outline-none">
            <option value="All">All</option>
            <option>Free</option><option>Freemium</option><option>Paid</option>
          </select>
        </FilterGroup>
        <div className="w-px h-4 bg-[var(--border)] shrink-0" />
        <FilterGroup label="Sort">
          <select value={sort} onChange={e => setSort(e.target.value as SortOption)}
                  className="text-sm bg-[var(--bg-2)] border border-[var(--border)] rounded-md px-2 py-1 text-[var(--text)] outline-none">
            <option value="newest">Newest</option>
            <option value="most-voted">Most voted</option>
            <option value="featured">Featured first</option>
            <option value="a-z">A–Z</option>
          </select>
        </FilterGroup>
        <span className="text-sm text-[var(--text-3)] ml-auto shrink-0">{filtered.length} tool{filtered.length !== 1 ? 's' : ''}</span>
        {/* View toggle */}
        <div className="flex border border-[var(--border)] rounded-lg overflow-hidden shrink-0">
          <button onClick={() => setView('grid')} className={`px-2.5 py-1.5 text-sm transition-colors ${view === 'grid' ? 'bg-[var(--text)] text-[var(--text-inv)]' : 'bg-[var(--surface)] text-[var(--text-3)] hover:bg-[var(--accent-soft)]'}`}>⊞</button>
          <button onClick={() => setView('list')} className={`px-2.5 py-1.5 text-sm transition-colors ${view === 'list' ? 'bg-[var(--text)] text-[var(--text-inv)]' : 'bg-[var(--surface)] text-[var(--text-3)] hover:bg-[var(--accent-soft)]'}`}>☰</button>
        </div>
      </div>

      {/* Tag filter indicator */}
      {tag && (
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs text-[var(--text-3)] uppercase tracking-wider font-bold">Tag:</span>
          <span className="tag tag-active">{tag}</span>
          <button onClick={() => setTag(null)} className="text-xs text-[var(--text-3)] hover:text-[var(--text)] border border-[var(--border)] rounded-full px-2 py-0.5 transition-colors">Clear ×</button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-[200px_1fr] gap-6 items-start">
        {/* Sidebar */}
        <aside className="hidden lg:block sticky top-20 bg-[var(--surface)] border border-[var(--border)] rounded-xl p-4">
          <div className="mb-5">
            <div className="text-[10px] uppercase tracking-widest text-[var(--text-3)] font-bold mb-2.5">Categories</div>
            <button onClick={() => setCategory('All')}
                    className={`w-full flex items-center justify-between px-2 py-1.5 rounded-md text-sm mb-0.5 transition-colors ${category === 'All' ? 'bg-[var(--accent-soft)] text-[var(--text)] font-medium' : 'text-[var(--text-2)] hover:bg-[var(--accent-soft)]'}`}>
              All <span className="text-xs text-[var(--text-3)]">{tools.length}</span>
            </button>
            {CATEGORIES.map(c => (
              <button key={c.name} onClick={() => setCategory(c.name)}
                      className={`w-full flex items-center justify-between px-2 py-1.5 rounded-md text-sm mb-0.5 transition-colors ${category === c.name ? 'bg-[var(--accent-soft)] text-[var(--text)] font-medium' : 'text-[var(--text-2)] hover:bg-[var(--accent-soft)]'}`}>
                <span>{c.icon} {c.name}</span>
                <span className="text-xs text-[var(--text-3)]">{catCounts[c.name]}</span>
              </button>
            ))}
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-widest text-[var(--text-3)] font-bold mb-2.5">Pricing</div>
            {(['All', 'Free', 'Freemium', 'Paid'] as const).map(p => (
              <button key={p} onClick={() => setPricing(p)}
                      className={`w-full flex items-center justify-between px-2 py-1.5 rounded-md text-sm mb-0.5 transition-colors ${pricing === p ? 'bg-[var(--accent-soft)] text-[var(--text)] font-medium' : 'text-[var(--text-2)] hover:bg-[var(--accent-soft)]'}`}>
                {p === 'All' ? 'All pricing' : p}
                {p !== 'All' && <span className="text-xs text-[var(--text-3)]">{priceCounts[p]}</span>}
              </button>
            ))}
          </div>
        </aside>

        {/* Grid / List */}
        <div>
          {filtered.length === 0
            ? <div className="text-center py-16 text-[var(--text-3)]"><div className="text-3xl mb-3 opacity-35">◯</div><h3 className="text-base font-medium text-[var(--text-2)] mb-1.5">No tools match</h3><p className="text-sm">Try broadening your filters.</p></div>
            : view === 'list'
              ? <div className="border border-[var(--border)] rounded-xl overflow-hidden">{filtered.map(t => <ToolListItem key={t.slug} tool={t} onVote={handleVote} hasVoted={hasVoted(t.slug)} />)}</div>
              : <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">{filtered.map(t => <ToolCard key={t.slug} tool={t} variant="m" onVote={handleVote} hasVoted={hasVoted(t.slug)} />)}</div>
          }
        </div>
      </div>
    </main>
  )
}

function FilterGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 shrink-0">
      <span className="text-[10px] text-[var(--text-3)] font-bold uppercase tracking-widest whitespace-nowrap">{label}</span>
      {children}
    </div>
  )
}
