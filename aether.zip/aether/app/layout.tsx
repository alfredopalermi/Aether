import type { Metadata } from 'next'
import { DM_Sans, DM_Serif_Display } from 'next/font/google'
import './globals.css'

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})
const dmSerif = DM_Serif_Display({
  subsets: ['latin'],
  weight: '400',
  style: ['normal', 'italic'],
  variable: '--font-dm-serif',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Aether — AI Tools, Curated',
  description: 'A curated library of AI tools for writers, designers, marketers, and knowledge workers.',
  openGraph: {
    title: 'Aether — AI Tools, Curated',
    description: 'Discover, save, and compare the best AI tools — all in one place.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{
          __html: `
            try {
              const t = localStorage.getItem('ae_theme');
              const p = window.matchMedia('(prefers-color-scheme: dark)').matches;
              if (t === 'dark' || (!t && p)) document.documentElement.classList.add('dark');
            } catch(e) {}
          `,
        }} />
      </head>
      <body className={`${dmSans.variable} ${dmSerif.variable}`}>
        {children}
      </body>
    </html>
  )
}
